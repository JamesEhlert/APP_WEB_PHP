// validation.js
document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector("form");
  
    form.addEventListener("submit", function(event) {
      const nameInput = form.querySelector("#name");
      const emailInput = form.querySelector("#email");
      const messageInput = form.querySelector("#message");
  
      if (nameInput.value.trim() === "") {
        alert("Por favor, preencha o campo de nome.");
        event.preventDefault();
        return;
      }
  
      if (emailInput.value.trim() === "") {
        alert("Por favor, preencha o campo de e-mail.");
        event.preventDefault();
        return;
      }
  
      if (messageInput.value.trim() === "") {
        alert("Por favor, preencha o campo de mensagem.");
        event.preventDefault();
        return;
      }
    });
  });
  